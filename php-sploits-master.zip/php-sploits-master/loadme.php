<?php
echo 'Hi there! You just loaded me from a URL';
