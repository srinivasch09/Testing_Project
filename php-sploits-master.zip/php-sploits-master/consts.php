<?php

define("DB_HOST", "localhost");
define("DB_USER", "changeme");
define("DB_PASS", "changeme");
define("DB_DB","sydphp");
